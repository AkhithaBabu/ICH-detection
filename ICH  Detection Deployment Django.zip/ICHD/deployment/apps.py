from django.apps import AppConfig


class DeploymentConfig(AppConfig):
    name = 'deployment'
